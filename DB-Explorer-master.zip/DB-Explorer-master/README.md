# 3380-DB-APP

Team 9:
- Nykolas Farhangi
- Anil Shanker
- Courtney Berry
- Jairo Pedroza

## Project Management System Database Front-End

This application provides a front-end user interface for any MySQL database.

## Usage

See usage instructions in `3380-backend` and `3380-frontend` folders.
